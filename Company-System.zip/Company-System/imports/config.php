<?php
    $server_name="localhost";
    $username="root";
    $password="Sarvesh@Anand@Mankar";
    $database_name="autoclick";
?>