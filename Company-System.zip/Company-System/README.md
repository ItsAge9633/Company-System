# endSemProject
CWIT End Semester Project

## Phases

![image](image.png)

## Beginner level ideas

![image](https://user-images.githubusercontent.com/56447720/156875917-9342f6a6-91d9-4f11-8320-f672d262f17a.png)

## Rapid API

![image](https://user-images.githubusercontent.com/56447720/156876155-0445b5be-b879-4431-88d7-d9272edc64ea.png)

## Intermidiate level

![image](https://user-images.githubusercontent.com/56447720/156876429-fa31f99c-5e29-4a69-b0d5-2d49008e3005.png)

## Advance full-stack development

![image](https://user-images.githubusercontent.com/56447720/156876844-0c57b00f-f1f1-4e08-85fd-97ca5e6359df.png)

## Project ideas 

![image](https://user-images.githubusercontent.com/56447720/156877094-3538c59f-fffb-4ad9-8730-60b6d4b874e2.png)

